import "fmt"

func() print{

}

func() main{
	var a [5][5] int

	reader := bufio.NewReader(os.Stdin)
	fmt.Print("Enter x coord: ")
	text, _ := reader.ReadString('\n')
	fmt.Print("Enter y coord: ")

	fmt.Println("hello")
}